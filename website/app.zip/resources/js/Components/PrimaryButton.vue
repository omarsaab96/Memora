<template>
    <button
        class="inline-flex items-center rounded-[30px] border border-transparent bg-[#00D6CA] px-4 py-2 text-white text-xs font-semibold uppercase tracking-widest  transition duration-300 ease-in-out hover:-translate-y-[2px]"
    >
        <slot />
    </button>
</template>
